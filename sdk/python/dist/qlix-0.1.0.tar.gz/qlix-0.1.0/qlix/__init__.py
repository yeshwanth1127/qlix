"""Qlix SDK — signed, audited tool execution for AI agents."""

from .exceptions import (
    DeviceNotVerifiedError,
    HttpError,
    IdentityError,
    JITTimeoutError,
    PermissionDeniedError,
    QlixError,
    ReplayError,
    ScopeError,
    SignatureError,
)
from .identity import (
    AgentIdentity,
    ENV_AGENT_FILE,
    extract_sdk_agent_file,
    load_identity,
    parse_identity,
    resolve_agent_json_path,
    save_sdk_agent_json,
)
from .sdk import QlixSDK
from .signer import canonicalize, sign_payload, verify_payload

__all__ = [
    "ENV_AGENT_FILE",
    "AgentIdentity",
    "DeviceNotVerifiedError",
    "HttpError",
    "IdentityError",
    "JITTimeoutError",
    "PermissionDeniedError",
    "QlixError",
    "QlixSDK",
    "ReplayError",
    "ScopeError",
    "SignatureError",
    "canonicalize",
    "extract_sdk_agent_file",
    "load_identity",
    "parse_identity",
    "resolve_agent_json_path",
    "save_sdk_agent_json",
    "sign_payload",
    "verify_payload",
]

__version__ = "0.1.0"
