"""OrchestratorAgent — multi-turn agent with tool-calling loop.

Supports two modes:

- **function_calling** (default): Uses OpenAI-format tool definitions and
  parses ``tool_calls`` from the engine response.
- **structured**: Uses a THOUGHT/TOOL/INPUT/FINAL_ANSWER text format
  (like ReAct) with a canonical system prompt from the orchestrator
  prompt registry.  This is the format used by the SFT/GRPO training
  pipelines, making the Orchestrator a distinctive trainable agent type.
"""

from __future__ import annotations

import concurrent.futures
import re
from typing import Any, List, Optional
from urllib.parse import quote_plus, urlparse

from qlix.luna.agents._stubs import AgentContext, AgentResult, ToolUsingAgent
from qlix.luna.core.events import EventBus
from qlix.luna.core.registry import AgentRegistry
from qlix.luna.core.types import Message, Role, ToolCall, ToolResult
from qlix.luna.engine._stubs import InferenceEngine
from qlix.luna.tools._stubs import BaseTool

_URL_IN_USER = re.compile(
    r"(https?://[^\s<>\"']+|[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+(?::\d+)?(?:/[^\s<>\"']*)?)",
    re.IGNORECASE,
)
_OPEN_VERB = re.compile(
    r"\b(open|launch|visit|show|navigate\s+to|go\s+to)\b",
    re.IGNORECASE,
)
_OPEN_TARGET = re.compile(
    r"\b(?:open|launch|visit|show|navigate\s+to|go\s+to)\s+([^\s<>\"']+)",
    re.IGNORECASE,
)
# "open X and search for Y" / "open X search for Y"
_SEARCH_FOR_TAIL = re.compile(
    r"(?i)\b(?:and\s+)?search\s+for\s+(.+?)\s*$",
)


@AgentRegistry.register("orchestrator")
class OrchestratorAgent(ToolUsingAgent):
    """Multi-turn agent that routes between tools and the LLM.

    Implements a tool-calling loop:
    1. Send messages with tool definitions to the engine.
    2. If the response contains tool_calls, execute them and loop.
    3. If no tool_calls, return the final answer.
    4. Stop after ``max_turns`` iterations.

    In **structured** mode the agent instead uses a
    ``THOUGHT: / TOOL: / INPUT: / FINAL_ANSWER:`` text protocol
    identical to the format used by the orchestrator SFT/GRPO
    training pipelines.
    """

    agent_id = "orchestrator"
    _default_temperature = 0.7
    _default_max_tokens = 1024
    _default_max_turns = 10

    def __init__(
        self,
        engine: InferenceEngine,
        model: str,
        *,
        tools: Optional[List[BaseTool]] = None,
        bus: Optional[EventBus] = None,
        max_turns: Optional[int] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        mode: str = "function_calling",
        system_prompt: Optional[str] = None,
        parallel_tools: bool = True,
        interactive: bool = False,
        confirm_callback=None,
    ) -> None:
        super().__init__(
            engine,
            model,
            tools=tools,
            bus=bus,
            max_turns=max_turns,
            temperature=temperature,
            max_tokens=max_tokens,
            interactive=interactive,
            confirm_callback=confirm_callback,
        )
        self._mode = mode
        self._system_prompt = system_prompt
        self._parallel_tools = parallel_tools

    def run(
        self,
        input: str,
        context: Optional[AgentContext] = None,
        **kwargs: Any,
    ) -> AgentResult:
        if self._mode == "structured":
            return self._run_structured(input, context, **kwargs)
        return self._run_function_calling(input, context, **kwargs)

    def _tool_by_id(self, tool_id: str) -> Optional[BaseTool]:
        for t in self._tools or []:
            tid = getattr(t, "tool_id", None)
            spec = getattr(t, "spec", None)
            name = spec.name if spec is not None else None
            if tool_id in {tid, name}:
                return t
        return None

    @staticmethod
    def _strip_trailing_url_punct(url: str) -> str:
        return url.rstrip(").,;\"'']}>")

    def _extract_openable_url(self, user_text: str) -> Optional[str]:
        m = _URL_IN_USER.search(user_text or "")
        if not m:
            # Fallback: capture first token after an "open" verb (e.g. "open youtube now")
            m2 = _OPEN_TARGET.search(user_text or "")
            if not m2:
                return None
            return self._strip_trailing_url_punct(m2.group(1))
        return self._strip_trailing_url_punct(m.group(0))

    @staticmethod
    def _host_from_open_url(url: str) -> str:
        u = (url or "").strip()
        if not u:
            return ""
        if not u.startswith(("http://", "https://")):
            u = f"https://{u}"
        parsed = urlparse(u)
        if parsed.netloc:
            return parsed.netloc.lower()
        if parsed.path:
            return parsed.path.split("/")[0].lower()
        return ""

    @classmethod
    def _apply_search_intent_to_url(cls, user_text: str, url: str) -> str:
        """If user asks to open a site and also 'search for Q', use the site search URL."""
        m = _SEARCH_FOR_TAIL.search((user_text or "").strip())
        if not m:
            return url
        q = m.group(1).strip().rstrip(".!?")
        if not q:
            return url
        host = cls._host_from_open_url(url)
        blob = f"{host} {url}".lower()

        if "wikipedia" in blob:
            return f"https://en.wikipedia.org/w/index.php?search={quote_plus(q)}"
        if "google" in blob:
            return f"https://www.google.com/search?q={quote_plus(q)}"
        if "youtube" in blob or "youtu.be" in blob:
            return f"https://www.youtube.com/results?search_query={quote_plus(q)}"
        if "bing" in blob:
            return f"https://www.bing.com/search?q={quote_plus(q)}"
        if "duckduckgo" in blob or "duck.com" in blob:
            return f"https://duckduckgo.com/?q={quote_plus(q)}"

        return url

    def _user_wants_open_url(self, user_text: str) -> bool:
        if not (user_text or "").strip():
            return False
        if _OPEN_VERB.search(user_text):
            return True
        t = (user_text or "").strip()
        if len(t) < 120 and _URL_IN_USER.fullmatch(t):
            return True
        return False

    def _fallback_open_system_url(
        self,
        user_input: str,
        *,
        total_prompt_tokens: int,
        total_completion_tokens: int,
        turns: int,
    ) -> Optional[AgentResult]:
        """Run open_system_url when local engines return no tool_calls."""
        tool = self._tool_by_id("open_system_url")
        if tool is None:
            return None
        if not self._user_wants_open_url(user_input):
            return None
        url = self._extract_openable_url(user_input)
        if not url:
            return None
        url = self._apply_search_intent_to_url(user_input, url)
        tr = tool.execute(url=url)
        return AgentResult(
            content=tr.content,
            tool_results=[tr],
            turns=turns,
            metadata={
                "prompt_tokens": total_prompt_tokens,
                "completion_tokens": total_completion_tokens,
                "total_tokens": total_prompt_tokens + total_completion_tokens,
                "open_url_fallback": True,
            },
        )

    # ------------------------------------------------------------------
    # Structured mode (THOUGHT/TOOL/INPUT/FINAL_ANSWER)
    # ------------------------------------------------------------------

    def _run_structured(
        self,
        input: str,
        context: Optional[AgentContext] = None,
        **kwargs: Any,
    ) -> AgentResult:
        self._emit_turn_start(input)

        # Build system prompt
        if self._system_prompt:
            sys_prompt = self._system_prompt
        else:
            try:
                from qlix.luna.learning.intelligence.orchestrator.prompt_registry import (
                    build_system_prompt,
                )

                sys_prompt = build_system_prompt(tools=self._tools)
            except ImportError:
                # Fallback when learning subsystem is not bundled (SDK build).
                tool_lines = "\n".join(
                    f"- {getattr(t, 'name', type(t).__name__)}: "
                    f"{getattr(t, 'description', '')}"
                    for t in (self._tools or [])
                )
                sys_prompt = (
                    "You are an autonomous agent. Use the available tools to "
                    "complete the user's task.\n\nAvailable tools:\n"
                    + (tool_lines or "(none)")
                )

        messages = self._build_messages(input, context, system_prompt=sys_prompt)

        all_tool_results: list[ToolResult] = []
        turns = 0

        for _turn in range(self._max_turns):
            turns += 1

            if self._loop_guard:
                messages = self._loop_guard.compress_context(messages)

            result = self._generate(messages)
            content = result.get("content", "")

            parsed = self._parse_structured_response(content)

            # FINAL_ANSWER -> done
            if parsed["final_answer"]:
                self._emit_turn_end(turns=turns)
                return AgentResult(
                    content=parsed["final_answer"],
                    tool_results=all_tool_results,
                    turns=turns,
                )

            # TOOL -> execute
            if parsed["tool"]:
                messages.append(Message(role=Role.ASSISTANT, content=content))

                tool_call = ToolCall(
                    id=f"orch_{turns}",
                    name=parsed["tool"],
                    arguments=parsed["input"] or "{}",
                )
                tool_result = self._executor.execute(tool_call)
                all_tool_results.append(tool_result)

                observation = f"Observation: {tool_result.content}"
                messages.append(Message(role=Role.USER, content=observation))
                continue

            # Neither -> treat content as final answer
            self._emit_turn_end(turns=turns)
            return AgentResult(
                content=content,
                tool_results=all_tool_results,
                turns=turns,
            )

        # Max turns exceeded
        return self._max_turns_result(all_tool_results, turns)

    @staticmethod
    def _parse_structured_response(text: str) -> dict:
        """Parse THOUGHT/TOOL/INPUT/FINAL_ANSWER from model output."""
        result = {
            "thought": "",
            "tool": "",
            "input": "",
            "final_answer": "",
        }

        thought_match = re.search(
            r"THOUGHT:\s*(.+?)(?=\nTOOL:|\nFINAL[_ ]?ANSWER:|\Z)",
            text,
            re.DOTALL | re.IGNORECASE,
        )
        if thought_match:
            result["thought"] = thought_match.group(1).strip()

        final_match = re.search(
            r"FINAL[_ ]?ANSWER:\s*(.+)",
            text,
            re.DOTALL | re.IGNORECASE,
        )
        if final_match:
            result["final_answer"] = final_match.group(1).strip()
            return result

        tool_match = re.search(r"TOOL:\s*(.+)", text, re.IGNORECASE)
        if tool_match:
            result["tool"] = tool_match.group(1).strip()

        input_match = re.search(
            r"INPUT:\s*(.+?)(?=\nTHOUGHT:|\nTOOL:|\nFINAL|\Z)",
            text,
            re.DOTALL | re.IGNORECASE,
        )
        if input_match:
            result["input"] = input_match.group(1).strip()

        return result

    # ------------------------------------------------------------------
    # Function-calling mode (original behaviour)
    # ------------------------------------------------------------------

    def _run_function_calling(
        self,
        input: str,
        context: Optional[AgentContext] = None,
        **kwargs: Any,
    ) -> AgentResult:
        self._emit_turn_start(input)

        # Build initial messages
        messages = self._build_messages(input, context)

        # Get OpenAI-format tool definitions
        openai_tools = self._executor.get_openai_tools() if self._tools else []

        all_tool_results: list[ToolResult] = []
        turns = 0
        total_prompt_tokens = 0
        total_completion_tokens = 0

        for _turn in range(self._max_turns):
            turns += 1

            if self._loop_guard:
                messages = self._loop_guard.compress_context(messages)

            # Build generate kwargs
            gen_kwargs: dict[str, Any] = {}
            if openai_tools:
                gen_kwargs["tools"] = openai_tools

            result = self._generate(messages, **gen_kwargs)

            # Accumulate token usage
            usage = result.get("usage", {})
            total_prompt_tokens += usage.get("prompt_tokens", 0)
            total_completion_tokens += usage.get("completion_tokens", 0)

            content = result.get("content", "")
            raw_tool_calls = result.get("tool_calls", [])

            # No tool calls -> check continuation, then final answer
            if not raw_tool_calls:
                content = self._check_continuation(result, messages)
                content = self._strip_think_tags(content)
                fb = self._fallback_open_system_url(
                    input,
                    total_prompt_tokens=total_prompt_tokens,
                    total_completion_tokens=total_completion_tokens,
                    turns=turns,
                )
                if fb is not None:
                    self._emit_turn_end(turns=turns, content_length=len(fb.content))
                    return fb
                self._emit_turn_end(turns=turns, content_length=len(content))
                return AgentResult(
                    content=content,
                    tool_results=all_tool_results,
                    turns=turns,
                    metadata={
                        "prompt_tokens": total_prompt_tokens,
                        "completion_tokens": total_completion_tokens,
                        "total_tokens": total_prompt_tokens + total_completion_tokens,
                    },
                )

            # Build ToolCall objects from raw dicts
            tool_calls = [
                ToolCall(
                    id=tc.get("id", f"call_{i}"),
                    name=tc.get("name", ""),
                    arguments=tc.get("arguments", "{}"),
                )
                for i, tc in enumerate(raw_tool_calls)
            ]

            # Append assistant message with tool calls
            messages.append(
                Message(
                    role=Role.ASSISTANT,
                    content=content,
                    tool_calls=tool_calls,
                )
            )

            # Execute each tool (with loop guard check) and append results
            if self._parallel_tools and len(tool_calls) > 1:
                # Parallel execution
                def _exec_tool(tc: ToolCall) -> tuple:
                    if self._loop_guard:
                        verdict = self._loop_guard.check_call(
                            tc.name,
                            tc.arguments,
                        )
                        if verdict.blocked:
                            return tc, ToolResult(
                                tool_name=tc.name,
                                content=f"Loop guard: {verdict.reason}",
                                success=False,
                            )
                    return tc, self._executor.execute(tc)

                with concurrent.futures.ThreadPoolExecutor(
                    max_workers=len(tool_calls),
                ) as pool:
                    futures = {pool.submit(_exec_tool, tc): tc for tc in tool_calls}
                    results_map: dict[int, tuple] = {}
                    for future in concurrent.futures.as_completed(futures):
                        tc_orig = futures[future]
                        results_map[id(tc_orig)] = future.result()

                # Append results in original order
                for tc in tool_calls:
                    _, tool_result = results_map[id(tc)]
                    all_tool_results.append(tool_result)
                    messages.append(
                        Message(
                            role=Role.TOOL,
                            content=tool_result.content,
                            tool_call_id=tc.id,
                            name=tc.name,
                        )
                    )
            else:
                # Sequential execution
                for tc in tool_calls:
                    # Loop guard check before execution
                    if self._loop_guard:
                        verdict = self._loop_guard.check_call(
                            tc.name,
                            tc.arguments,
                        )
                        if verdict.blocked:
                            tool_result = ToolResult(
                                tool_name=tc.name,
                                content=f"Loop guard: {verdict.reason}",
                                success=False,
                            )
                            all_tool_results.append(tool_result)
                            messages.append(
                                Message(
                                    role=Role.TOOL,
                                    content=tool_result.content,
                                    tool_call_id=tc.id,
                                    name=tc.name,
                                )
                            )
                            continue

                    tool_result = self._executor.execute(tc)
                    all_tool_results.append(tool_result)

                    # Append tool response message
                    messages.append(
                        Message(
                            role=Role.TOOL,
                            content=tool_result.content,
                            tool_call_id=tc.id,
                            name=tc.name,
                        )
                    )

        # Max turns exceeded
        final_content = self._strip_think_tags(content) if content else ""
        self._emit_turn_end(turns=turns, max_turns_exceeded=True)
        return AgentResult(
            content=final_content or "Maximum turns reached without a final answer.",
            tool_results=all_tool_results,
            turns=turns,
            metadata={
                "max_turns_exceeded": True,
                "prompt_tokens": total_prompt_tokens,
                "completion_tokens": total_completion_tokens,
                "total_tokens": total_prompt_tokens + total_completion_tokens,
            },
        )


__all__ = ["OrchestratorAgent"]
